using Microsoft.AspNetCore.Mvc;

namespace Funcionalide_Diogo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
