using Microsoft.AspNetCore.Mvc;
using Funcionalide_Diogo.Models;

namespace Funcionalide_Diogo.Controllers
{
    public class PesagemController : Controller
    {
        private readonly AppDbContext _context;

        public PesagemController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var pesagens = _context.Pesagens.ToList();
            return View(pesagens);
        }

        public IActionResult Cadastrar()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Pesagem pesagem)
        {
            if (ModelState.IsValid)
            {
                _context.Pesagens.Add(pesagem);
                _context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            return View(pesagem);
        }
    }
}
