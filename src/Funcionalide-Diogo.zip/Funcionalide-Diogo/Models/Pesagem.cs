using System;
using System.ComponentModel.DataAnnotations;

namespace Funcionalide_Diogo.Models
{
    public class Pesagem
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "O peso é obrigatório.")]
        [Display(Name = "Peso (kg)")]
        public double Peso { get; set; }

        [Required(ErrorMessage = "Informe o tipo de material.")]
        [Display(Name = "Tipo de Material")]
        public string TipoMaterial { get; set; }

        [Required(ErrorMessage = "Informe a localização.")]
        [Display(Name = "Localização")]
        public string Localizacao { get; set; }

        [Display(Name = "Data de Cadastro")]
        public DateTime DataCadastro { get; set; } = DateTime.Now;
    }
}
