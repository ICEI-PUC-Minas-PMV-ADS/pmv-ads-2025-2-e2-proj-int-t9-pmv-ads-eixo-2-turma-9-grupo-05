# Funcionalide-Diogo (ASP.NET Core MVC - .NET 8)

Projeto pronto para rodar localmente usando SQLite (não precisa configurar SQL Server).

Como usar:
1. Extraia o ZIP e abra `Funcionalide-Diogo.csproj` no Visual Studio 2022/2023.
2. No Visual Studio, pressione Ctrl+F5 para executar.
3. O arquivo SQLite `Data/FuncionalideDiogo.db` será criado automaticamente (ou preenchido).

Observação importante:
- É necessário que o .NET 8 runtime esteja instalado na máquina para executar o projeto. 
  Visual Studio geralmente já traz o runtime quando instalado. Se houver erro indicando falta de SDK/runtime, instale o .NET 8 runtime.
