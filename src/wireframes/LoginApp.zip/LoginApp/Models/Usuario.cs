using Microsoft.EntityFrameworkCore;

namespace LoginApp.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Nome { get; set; } = "";
        public string Senha { get; set; } = "";
        public string Tipo { get; set; } = ""; // "comum" ou "empresa"
    }

    public class AppDbContext : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}