# LoginApp (ASP.NET Core MVC + SQLite)

Projeto mínimo de exemplo com uma tela de login (Usuário Comum / Empresa) usando ASP.NET Core MVC e SQLite.

## Como rodar
1. Instale .NET SDK 8.0+: https://dotnet.microsoft.com/download
2. Abra a pasta `LoginApp` no Visual Studio Code ou Visual Studio.
3. No terminal, execute:
   ```
   dotnet restore
   dotnet run
   ```
4. Abra no navegador: https://localhost:5001 (ou http://localhost:5000)

## Logins de teste
- Usuário comum: usuario / 123 (tipo: comum)
- Empresa: empresa / 123 (tipo: empresa)