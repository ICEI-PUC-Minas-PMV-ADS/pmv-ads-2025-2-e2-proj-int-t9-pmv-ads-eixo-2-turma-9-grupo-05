using Microsoft.AspNetCore.Mvc;
using LoginApp.Models;
using System.Linq;

namespace LoginApp.Controllers
{
    public class LoginController : Controller
    {
        private readonly AppDbContext _context;

        public LoginController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string username, string password, string tipo)
        {
            var usuario = _context.Usuarios
                .FirstOrDefault(u => u.Nome == username && u.Senha == password && u.Tipo == tipo);

            if (usuario != null)
            {
                // Simples redirect para uma view de boas-vindas; você pode alterar para dashboards.
                TempData["Mensagem"] = $"✅ Login realizado! Bem-vindo, {usuario.Nome} ({usuario.Tipo}).";
                return RedirectToAction("Index", "Login");
            }

            ViewBag.Erro = "Usuário ou senha incorretos.";
            return View();
        }
    }
}