
// ==========================================
// Projeto: Sistema de Monitoramento de Resíduos
// Funcionalidade: Consulta de Pesagens
// Linguagem: C# (ASP.NET Core MVC Minimal)
// ==========================================

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

// ===============================
// Modelo (Model)
// ===============================
public class Pesagem
{
    public int Id { get; set; }
    public string Empresa { get; set; }
    public string TipoResiduo { get; set; } // Orgânico, Reciclável, Rejeito
    public double PesoKg { get; set; }
    public DateTime DataColeta { get; set; }
}

// ===============================
// Rota principal
// ===============================
app.MapGet("/Pesagem/Consulta", (HttpContext context) =>
{
    string? tipoResiduo = context.Request.Query["tipoResiduo"];
    string? empresa = context.Request.Query["empresa"];

    var pesagens = new List<Pesagem>
    {
        new Pesagem { Id = 1, Empresa = "EcoLimpo", TipoResiduo = "Reciclável", PesoKg = 120.5, DataColeta = new DateTime(2025, 10, 22) },
        new Pesagem { Id = 2, Empresa = "VerdeColeta", TipoResiduo = "Orgânico", PesoKg = 85.3, DataColeta = new DateTime(2025, 10, 23) },
        new Pesagem { Id = 3, Empresa = "ReciclaMais", TipoResiduo = "Rejeito", PesoKg = 45.9, DataColeta = new DateTime(2025, 10, 24) },
        new Pesagem { Id = 4, Empresa = "EcoLimpo", TipoResiduo = "Orgânico", PesoKg = 90.2, DataColeta = new DateTime(2025, 10, 25) }
    };

    var lista = pesagens.AsQueryable();

    if (!string.IsNullOrEmpty(tipoResiduo))
        lista = lista.Where(p => p.TipoResiduo.Contains(tipoResiduo, StringComparison.OrdinalIgnoreCase));

    if (!string.IsNullOrEmpty(empresa))
        lista = lista.Where(p => p.Empresa.Contains(empresa, StringComparison.OrdinalIgnoreCase));

    var html = $@"
<!DOCTYPE html>
<html lang='pt-br'>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Consulta de Pesagens</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='bg-light'>
    <div class='container mt-5'>
        <h2 class='text-center mb-4'>Consulta de Pesagens</h2>
        <form method='get' class='row mb-4'>
            <div class='col-md-5'>
                <input type='text' name='empresa' class='form-control' placeholder='Buscar por empresa' value='{empresa ?? ""}' />
            </div>
            <div class='col-md-5'>
                <input type='text' name='tipoResiduo' class='form-control' placeholder='Buscar por tipo de resíduo' value='{tipoResiduo ?? ""}' />
            </div>
            <div class='col-md-2'>
                <button type='submit' class='btn btn-success w-100'>Filtrar</button>
            </div>
        </form>

        <table class='table table-striped table-hover shadow-sm'>
            <thead class='table-success'>
                <tr>
                    <th>ID</th>
                    <th>Empresa</th>
                    <th>Tipo de Resíduo</th>
                    <th>Peso (kg)</th>
                    <th>Data da Coleta</th>
                </tr>
            </thead>
            <tbody>";

    if (lista.Any())
    {
        foreach (var item in lista)
        {
            html += $@"
                <tr>
                    <td>{item.Id}</td>
                    <td>{item.Empresa}</td>
                    <td>{item.TipoResiduo}</td>
                    <td>{item.PesoKg}</td>
                    <td>{item.DataColeta:dd/MM/yyyy}</td>
                </tr>";
        }
    }
    else
    {
        html += "<tr><td colspan='5' class='text-center text-muted'>Nenhuma pesagem encontrada.</td></tr>";
    }

    html += @"
            </tbody>
        </table>
    </div>
</body>
</html>";

    return Results.Content(html, "text/html");
});

app.Run();
