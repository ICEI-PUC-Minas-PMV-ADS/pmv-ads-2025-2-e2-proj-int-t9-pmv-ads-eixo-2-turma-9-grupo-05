using Microsoft.EntityFrameworkCore;
using EcoTrash.Models;

namespace EcoTrash.Data
{
    public class EcoTrashContext : DbContext
    {
        public EcoTrashContext(DbContextOptions<EcoTrashContext> options)
            : base(options)
        {
        }

        public DbSet<Empresa> Empresas { get; set; }
    }
}
