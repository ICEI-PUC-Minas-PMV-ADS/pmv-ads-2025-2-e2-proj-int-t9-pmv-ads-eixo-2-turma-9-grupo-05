using System.ComponentModel.DataAnnotations;

namespace EcoTrash.Models
{
    public class Empresa
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome da empresa é obrigatório.")]
        [StringLength(100)]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "O CNPJ é obrigatório.")]
        [StringLength(18)]
        public string Cnpj { get; set; } = string.Empty;

        [StringLength(100)]
        public string? Endereco { get; set; }

        [StringLength(50)]
        public string? Telefone { get; set; }

        [EmailAddress]
        public string? Email { get; set; }
    }
}
