Versão corrigida com o logo original EcoTrash (logo.png)
Arquivos:
- index.html
- styles.css
- README.txt
- logo.png (adicione este arquivo manualmente na mesma pasta)

Abra index.html no navegador para visualizar.
